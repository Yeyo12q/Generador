<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <title>GeneradorCheap<?php if (!empty($title)) { echo ' - '.$title; } ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="title" content="RyzoGen - Premier Générateur de France">
        <meta name="description" content="RyzoGen vous permet de générer des comptes premium sur une vaste gamme de services, y compris les films, la télévision, les sports, le contenu pour adultes, les jeux vidéo et bien plus encore et cela 100% Gratuitement en 2 clics !"/>
        <meta name="keywords" content="générateur, generateur, freegen, freegen.fr, FreeGen, FreeGen.fr, générateur gratuit, comptes, spotify gratuit, spotify premium free, free, gen, freegenerateur, generateur de comptes, générateur de comptes gratuit, genfree, twitter freegen, discord freegen, netflix free, spotify free, netflix premium, netflix gratuit, netflix premium gratuit, proxy hq, proxy hq gratuits, pornhub comptes, pornhub free, deezer free, deezer gratuit, freegen.io, freegenio, lightgenvip, lightgen, flipgen, bloumegen, fgenfr"/>
        
        <meta property="og:type" content="website"/>
        <meta property="og:title" content="RyzoGen - Premier Générateur de France"/>
        <meta property="og:description" content="RyzoGen vous permet de générer des comptes premium sur une vaste gamme de services, y compris les films, la télévision, les sports, le contenu pour adultes, les jeux vidéo et bien plus encore et cela 100% Gratuitement en 2 clics !">
        <meta property="twitter:card" content="summary_large_image"/>
        <meta property="twitter:title" content="RyzoGen - Premier Générateur de France"/>
        <meta property="twitter:description" content="RyzoGen vous permet de générer des comptes premium sur une vaste gamme de services, y compris les films, la télévision, les sports, le contenu pour adultes, les jeux vidéo et bien plus encore et cela 100% Gratuitement en 2 clics !">
        <meta property="twitter:image" content="https://i.imgur.com/buR4vxW.jpg"/>
        
        <link rel="shortcut icon" href="/assets/images/favicon.ico"/>

        <link href="/assets/css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css"/>
        <link href="/assets/css/vendor/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="/assets/css/vendor/responsive.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css"/>
        
        <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style"/>
        <link href="/assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style"/>
        <link href="/assets/css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":true, "showRightSidebarOnStart": false}'>
 
        <!-- Pre-loader -->
            <div id="preloader">
            <div id="status">
                <div class="bouncing-loader"><div ></div><div ></div><div ></div></div>
            </div>
        </div>
        <!-- End Preloader-->
 
        <!--<div id="attention">
            <h1>Il semble que vous utilisiez un bloqueur de publicités. Entre nous, qui ne le fait pas?<br>
            Mais sans revenus publicitaires, nous ne pouvons pas continuer à rendre ce site génial.<br>
            <a href="javascript:document.location.reload()" style="pointer-events:auto">Je comprends, j'ai désactivé mon bloqueur de publicités. Laisse moi générer !</a></h1>
        </div>-->
        <script>
        if (!document.getElementById('g25fvgfdgfd')) {
            document.getElementById('attention').style.display = 'block';
            document.body.style.pointerEvents = 'none';
            document.body.style.overflow = 'hidden';
            document.body.style.userSelect = 'none';
        }
        </script>
        <div class="wrapper">
           