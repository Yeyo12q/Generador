<?php
require('inc/fonctions.php');

if (!check_login()){
    header('Location: /connexion');
    exit();
}


$title = 'Faq';
require('inc/header_panel.php');

// Menu a gauche
require('inc/menu_panel.php');

// Menu en haut
require('inc/menu_haut.php');

?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/">FreeGen</a></li>
                        <li class="breadcrumb-item"><a href="/">Manager</a></li>
                        <li class="breadcrumb-item active">F.A.Q</li>
                    </ol>
                </div>
                <h4 class="page-title">F.A.Q</h4>
            </div>
        </div>
    </div>

<div class="row">
             <div class="col-sm-12">
                 <br>
                 <br>
    
                                </div>
                            </div><!-- end col -->
                        
        
                        <div class="row pt-20">
                            <div class="col-lg-10 offset-lg-1">
                                <!-- Question/Answer -->
                                <div>
									      <div class="text-center">
                                    <h3 class="">Preguntas Frecuentes </h3>
                                    <p class="text-muted mt-3">Notamos que muchos de ustedes están haciendo las mismas preguntas, nuestro equipo de soporte ha inventado sus preguntas más solicitadas. Si aún necesita ayuda después de eso.</p>
        
                                 <a href="javascript:void($crisp.push(['do', 'chat:open']))" class="btn btn-success btn-sm mt-2" data-cf-modified-a1999ced2180f541624fe3e5-=""><i class="mdi mdi-email-outline mr-1"></i> Contactez le Support</button>
                                 <a href="https://twitter.com/FreeGenIsBack_" target="_blank" class="btn btn-info btn-sm mt-2 ml-1"><i class="mdi mdi-twitter mr-1"></i> Tweetez nous</a>
                                </div>
                            </div><!-- end col -->
                        </div><!-- end row -->
        
                        <div class="row pt-5">
                            <div class="col-lg-5 offset-lg-1">
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question" data-wow-delay=".1s">¿Cada Cuánto Tiempo Se Agregan Cuentas?</h4>
                                    <p class="faq-answer mb-4">Eh bien  <?=$utilisateur['pseudo'] ?>, Bueno Uno, no tenemos una fecha específica para la reposición de existencias, tan pronto como podamos dar una advertimos con un máximo de 1 día de anticipación.</p>
                                </div>
        
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question">¿Por qué está marcado como "Reservado para VIP" ?</h4>
                                    <p class="faq-answer mb-4">Todas las categorías de cuenta están disponibles para todos los grados hasta que el stock alcance los 20, después de este umbral el generador entra en "Reservado para VIP".</p>
                                </div>
        
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question">¿Por qué está deshabilitado el generador [.] ?</h4>
                                    <p class="faq-answer mb-4">El generador se puede desactivar por varias razones, esperando la reposición, problemas con el stock, actualización del generador...</p>
                                </div>
        
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question" data-wow-delay=".1s">¿Cuántas cuentas puedo generar por día ?</h4>
                                    <p class="faq-answer mb-4">Las generaciones diarias varían según el grado, Usuario: 1 Y VIP: 25 Por Dia</p>
                                </div>
        
                            </div>
                            <!--/col-md-5 -->
        
                            <div class="col-lg-5">
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question">¿Por qué mi cuenta no funciona ?</h4>
                                    <p class="faq-answer mb-4">Todas las cuentas se verifican antes de un tiempo, las personas saben cuándo una persona está iniciando sesión en su cuenta y se ven obligadas a cambiar su contraseña.</p>
                                </div>
        
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question">¿Cuando intento generar una cuenta, aparece una ventana emergente en el medio de la página ?</h4>
                                    <p class="faq-answer mb-4">Este problema ocurre cuando tienes un bloqueador de anuncios (AdBlock..), estos anuncios contribuyen al pago del sitio y son necesarios.</p>
                                </div>
        
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question">¿No puedo generar una cuenta, uso Brave como navegador ? ?</h4>
                                    <p class="faq-answer mb-4">Desafortunadamente, el sitio no funciona con Brave, la única solución es cambiar el navegador.</p>
                                </div>
        
                                <!-- Question/Answer -->
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question">He generado cuentas adicionales, ¿puedo ponerlas a la venta ?</h4>
                                    <p class="faq-answer mb-4">Claro Que Si</p>
                                </div>
        
        
                                
                            
                            <!--/col-md-5-->
                        </div>
                        <!-- end row -->
                        
                    </div> <!-- container -->

                </div> <!-- content -->

                <!-- Footer Start -->

            </div>

            <?php require('inc/footer_panel.php'); ?>