<?php
require('inc/fonctions.php');

// Formulaire inscription

if (check_login()) {
    header('Location: /');
}

$title = 'Inscription';
require('inc/header_auth.php');
?>
<?php if (empty($_GET['mail'])) { ?>
<div class="card cta-box bg-primary text-white">
    <div class="card-body">
        <div class="text-center">
            <h3 class="m-0 font-weight-normal cta-box-title">Únete A Nuestro<b>Telegram ?</b></h3>
            <br>
            <a target="_blank" href="https://discord.gg/freegen-1-1084224540231606282" class="btn btn-sm btn-light btn-rounded">Unirse <i class="mdi mdi-arrow-right"></i></a>
        </div>
    </div>
</div>
<?php } ?>
<div class="card">
    <div class="card-header pt-4 pb-4 text-center bg-primary">
        <a href="/">
            <img src="/assets/images/logo.png" alt="Logo" height="55">
        </a>
    </div>
    <div class="card-body p-4">
        <div class="text-center w-75 m-auto">
            <?php if (!empty($_GET['mail'])) { ?>
            <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Migration</h4>
            <p class="text-muted mb-4" id="message">Vous avez presque fini la migration de votre compte !</p>
            <?php } else { ?>
            <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Inscripción</h4>
            <p class="text-muted mb-4" id="message">¿Todavía no hay cuenta ? Regístrese, toma menos de un minuto.</p>
            <?php } ?>
            <div id="alert"></div>
        </div>
        <form method="POST" async="inscription">
            <div class="form-group">
                <label for="pseudo">Su Apodo</label>
                <input type="text" class="form-control" name="pseudo" id="pseudo" placeholder="Ingrese Su Apodo" required/>
            </div>

            <div class="form-group">
                <label for="mail">Su dirección de correo electrónico</label>
                <?php if (!empty($_GET['mail'])) { ?>
                <input type="email" class="form-control" name="mail" id="mail" value="<?=$_GET['mail'] ?>" required/>
                <?php } else { ?>
                <input type="email" class="form-control" name="mail" id="mail" placeholder="Ingrese Su Correo Electrónico" required/>
                <?php } ?>
            </div>

            <div class="form-group">
                <span class="text-muted float-right"><small id="password_message">No se ingresó ninguna contraseña</small></span>
                <label for="motdepasse">Su Contraseña</label>
                <input type="password" class="form-control" name="motdepasse" id="motdepasse" placeholder="Ingrese Su Contraseña " onkeyup="password(this)" required/>
            </div>

            <div class="form-group">
                <label for="motdepasse2">Confirmación de su contraseña</label>
                <input type="password" class="form-control" name="motdepasse2" id="motdepasse2" placeholder="Confirmación De Contraseña" required/>
            </div>

            <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" name="cgu" id="cgu" required/>
                    <label class="custom-control-label" for="cgu">Acepto Los <a class="text-muted">CGU</a></label>
                </div>
            </div>
            
            <div class="form-group" align="center">
                <div class="g-recaptcha" data-theme="dark" data-sitekey="6Ldf_cApAAAAABVjmq1BzGlztJDPkeHw1nsureFY"></div>
            </div>

            <div class="form-group mb-0 text-center">
                <?php if (!empty($_GET['mail'])) { ?>
                <input type="hidden" name="migre" value="1"/>
                <?php } ?>
                <input type="hidden" name="token" value="<?=$_SESSION['token'] ?>"/>
                <input type="submit" class="btn btn-primary" value="Registrarse"/>
            </div>
        </form>
    </div>
</div>
<div class="row mt-3">
    <div class="col-12 text-center">
        <p class="text-muted">¿Ya tienes una cuenta ? <a href="/connexion" class="text-muted ml-1"><b>Identificar</b></a></p>
  </body>
</div>
<?php require('inc/footer_auth.php') ?>