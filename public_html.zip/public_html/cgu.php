<?php
require('inc/fonctions.php');

if (!check_login()){
    header('Location: /connexion');
    exit();
}

$title = 'CGU';
require('inc/header_panel.php');

// Menu a gauche
require('inc/menu_panel.php');

// Menu en haut
require('inc/menu_haut.php');
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/">GeneradorCheap</a></li>
                        <li class="breadcrumb-item"><a href="/">Manager</a></li>
                        <li class="breadcrumb-item active">CGU</li>
                    </ol>
                </div>
                <h4 class="page-title">CGU</h4>
            </div>
        </div>
    </div>
<div class="row">

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/MD3Tcb4.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/wrFrFyp.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/G1fje6A.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/fDuHdHl.gif"></a>
</div>
</div>
</div>
</div>
</div>

         <div class="col-md-12">
			
                            <div class="box">
                                <div class="card">
                                                    <div>
                                                            <div class="box-body ribbon-box">
                                            <div class="ribbon-two ribbon-two-info"><span>CGU</span></div>
                                                        <div class="row">
                                                            <div class="col-lg-9 col-sm-8">
                                                                <div class="p-4">
                                                                    <h5 class="text-primary">Voici les CGU de GeneradorCheap, <?=$utilisateur['pseudo'] ?> !
                </h5>
                
                                                                     <div class="text-muted">
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Vous ne pouvez pas partager ou vendre l'accès à votre compte FreeGen !</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Il n'y a aucun remboursement en aucun cas. TOUTES LES VENTES SONT FINALES.</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Vous ne pouvez pas refacturer votre paiement. Si vous le faites, vous en acceptez les conséquences !</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Vous ne pouvez pas modifier les mots de passe des comptes !</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Nous pouvons supprimer des sites à notre discrétion avec ou sans préavis !</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Nous avons le droit d'interdire les utilisateurs pour quelque raison que ce soit !</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Vous ne tenterez en aucun cas de manipuler la sécurité de ce site Web.</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Nous pouvons interdire votre compte pour quelque raison que ce soit si nous le jugeons nécessaire.</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> Nous pouvons fermer ce site Web temporairement ou définitivement à tout moment avec ou sans préavis</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> FreeGen ne sera pas responsable de tout ce que vous faites en utilisant notre site Web.</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i> FreeGen se réserve le droit de modifier ces conditions à tout moment avec ou sans préavis.</p>
                                                                        <p class="mb-0"><i class="fa fa-circle align-middle text-primary mr-1"></i> Des tarifs pour vous satisfaire aux meilleurs prix !</p><br>
                                                                    <p><b>La violation de l'une de ces conditions est un motif de résiliation de votre compte sans remboursement !</b></p><br>
                                                                    <p><b>Date: 25/06/2021</b></p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-3 col-sm-4 align-self-center">
                    </td>
                    </tr>                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
                            <div class="col-lg-4">
                                <div class="card text-white bg-info overflow-hidden">
                                    <div class="card-body">
                                        <div class="toll-free-box text-center">
                                            <h4> <i class="mdi mdi-discord"></i> Une question ? Rejoignez le <a href="https://discord.gg/Y4GXehe8ac" target="_blank">Discord</a></h4>
                                        </div>
                                    </div> <!-- end card-body-->
                                </div>
                            </div> <!-- end col-->

                            <div class="col-lg-4">
                                <div class="card text-white bg-danger overflow-hidden">
                                    <div class="card-body">
                                        <div class="toll-free-box text-center">
                                             <h4> <i class="mdi mdi-instagram"></i> Besoin d'aide ? Contactez-nous <a href="https://www.instagram.com/generadorcheap.xyz?igsh=MXN5dGhzM2l2cWFraw==" target="_blank">Instagram</a></h4>
                                        </div>
                                    </div> <!-- end card-body-->
                                </div>
                            </div> <!-- end col-->

                            <div class="col-lg-4">
                                <div class="card bg-success text-white overflow-hidden">
                                    <div class="card-body">
                                       <div class="toll-free-box text-center">
                                             <h4> <i class="mdi mdi-twitter"></i> Un problème ? Tweetez-nous sur <a href="https://twitter.com/FreeGenisback_" target="_blank">Twitter</a></h4>
                                        </div>
                                    </div> <!-- end card-body-->
                                </div>
                            </div> <!-- end col-->
                        </div>
<?php require('inc/footer_panel.php'); ?>