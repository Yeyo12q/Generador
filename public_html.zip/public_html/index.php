<?php
require('inc/fonctions.php');

if (!check_login()){
    header('Location: /connexion');
    exit();
}

if(isset($_POST['generer'])){
    $_SESSION['token_gen'] = time();
    if ($utilisateur['grade'] == 1) {
        if(isset($_POST['linkvert'])){
            $_SESSION['token_lv'] = random_bytes(5);
            header('Location: '.$_POST['linkvert']);

        }else{
            $token_exeio = '51f0135ae371b3c8b651400794851ca950b8d846';
            $genid = htmlspecialchars($_POST['generer']);
            $aprespub = 'https://'.$_SERVER['HTTP_HOST'].'/captcha?id='.$genid;
            $url = 'https://exe.io/st?api='.$token_exeio.'&url='.$aprespub;
            header('Location: '.$url);
        }
    } else {
        $genid = htmlspecialchars($_POST['generer']);
        $url = '/captcha?id='.$genid;
        header('Location: '.$url);
    }
}


$title = 'Générateurs';
require('inc/header_panel.php');

// Menu a gauche
require('inc/menu_panel.php');

// Menu en haut
require('inc/menu_haut.php');
?>
<script src="https://use.fontawesome.com/c71cc2c5b0.js"></script>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/">GeneradorCheap</a></li>
                        <li class="breadcrumb-item"><a href="/">Manager</a></li>
                        <li class="breadcrumb-item active">Generadores</li>
                    </ol>
                </div>
                <h4 class="page-title">Bienvenido a GeneradorCheap</h4>
            </div>
        </div>
    </div>
<div class="row">

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/MD3Tcb4.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/wrFrFyp.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/G1fje6A.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/fDuHdHl.gif"></a>
</div>
</div>
</div>
</div>
</div>
         <div class="col-md-12">

                            <div class="box">
                                <div class="card">
                                                    <div>
                                                            <div class="box-body ribbon-box">
                                            <div class="ribbon-two ribbon-two-info"><span>Bienvenidos</span></div>
                                                        <div class="row">
                                                            <div class="col-lg-9 col-sm-8">
                                                                <div class="p-4">
                                                                    <h5 class="text-primary">Bienvenidos a la version official, <?=$utilisateur['pseudo'] ?> !
                </h5>
                                                                    <p>#1 - Generador latino.</p>

                                                                    <div class="text-muted">
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i>  Mas de 40 tipos de cuentas.</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i>  Restablecimiento regular de cuentas.</p>
                                                                        <p class="mb-1"><i class="fa fa-circle align-middle text-primary mr-1"></i>  Tarifas a los mejores precios !</p>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-3 col-sm-4 align-self-center">
                                                                <div>
                                                                    <img src="https://i.ibb.co/mN40t5g/img-1.png" width="250" alt="" class="img-fluid d-block">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                    </div></div>

    <div class="row">
        <div class="col-12">
            <div class="card widget-inline">
                <div class="card-body p-0">
                    <div class="row no-gutters">
                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0">
                                <div class="card-body text-center">
                                    <i class="dripicons-user-group text-muted" style="font-size:24px"></i>
                                    <h3><span><?=get_utilisateurs() ?></span></h3>
                                    <p class="text-muted font-15 mb-0">Usuarios registrados</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0 border-left">
                                <div class="card-body text-center">
                                    <i class="dripicons-checklist text-muted" style="font-size:24px"></i>
                                    <h3><span><?=get_generateurs() ?></span></h3>
                                    <p class="text-muted font-15 mb-0">Generadores</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0 border-left">
                                <div class="card-body text-center">
                                    <i class="dripicons-box text-muted" style="font-size:24px"></i>
                                    <h3><span><?=get_user_gen($utilisateur['id']) ?></span></h3>
                                    <p class="text-muted font-15 mb-0">tus generaciones</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-3">
                            <div class="card shadow-none m-0 border-left">
                                <div class="card-body text-center">
                                    <i class="dripicons-graph-line text-muted" style="font-size:24px"></i>
                                    <h3><span><?=get_generations_g() ?></span> <i class="mdi mdi-arrow-up text-success"></i></h3>
                                    <p class="text-muted font-15 mb-0">Generaciones globales</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="row">
   <div class="col-xl-5 col-lg-5">
     <div class="card ribbon-box">
       <div class="card-body">
         <div class="ribbon ribbon-primary float-right"><i class="mdi mdi-access-point mr-1"></i> Hey !</div>
                                         <span class="float-left m-2 mr-4">
                                    <?php if (!empty($utilisateur['avatar'])) { ?>
                                        <img src="<?=$utilisateur['avatar'] ?>" style="width:100px;height:100px" class="rounded-circle img-thumbnail">
                                    <?php } else { ?>
                                        <img src="/assets/images/avatar.jpg" style="width:100px;height:100px" class="rounded-circle img-thumbnail">
                                    <?php } ?>
                                </span>
                                        </span>
                                        <div class="">
                                            <h4 class="mt-1 mb-1"><?=$utilisateur['pseudo'] ?></h4>
                                            <p class="font-13"><?=get_grade($utilisateur['id'], 'lettres') ?></p>
                                    
                                            <ul class="mb-0 list-inline">
                                                <li class="list-inline-item mr-3" id="gen">
                                                    <h5 class="mb-1"><?=get_user_gen($utilisateur['id']) ?></h5>
                                                    <p class="mb-0 font-13">Tus generaciones</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

    <?php if (activation_maintenance()) {
        $req = $bdd->query('SELECT * FROM alerts WHERE connecte = 1 AND affiche = 1 ORDER BY id DESC');
        while($r = $req->fetch()) {
        ?>
        <div class="col-xl-7 col-lg-7">
            <div class="card cta-box bg-<?=$r['type'] ?> text-white">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="media-body">
                            <h3 class="mt-0"><i class="mdi mdi-bullhorn-outline" style="font-size:40px"></i>&nbsp;</h3>
                            <h3 class="m-0 font-weight-normal cta-box-title"><?=$r['titre'] ?> <?=$r['contenu'] ?><i class="mdi mdi-arrow-right"></i></h3>
                        </div>
                        <img class="ml-3" src="/assets/images/HII.png" width="100"/>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    <?php } else { ?>
        <div class="col-xl-7 col-lg-7">
            <div class="card cta-box bg-danger text-white">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="media-body">
                            <h2 class="mt-0"><i class="mdi mdi-cogs"></i>&nbsp;</h2>
                            <h3 class="m-0 font-weight-normal cta-box-title">Le générateur est en <b>maintenance</b>. Seuls les Admins, Responsables et Fournisseurs peuvent se connecter. <i class="mdi mdi-arrow-right"></i></h3>
                        </div>
                        <img class="ml-3" src="/assets/images/maintenance.svg" width="120"/>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
    </div>

    <div class="row">
        <?php
        $getGenMEA = get_generateur_MEA();
        while ($generateur = $getGenMEA->fetch()) {
            $stock = get_stock($generateur['id']);

        ?>
        <div class="col-md-6 col-xl-3">

            <div class="card d-block">
                <img class="card-img-top" width="10" src="<?=$generateur['icon_gif'] ?>" alt="<?=$generateur['nom'] ?>">

                <div class="card-img-overlay">
                    <?php if ($stock >= 1) { ?>
                    <div class="badge badge-success p-1">En stock</div>
                    <?php } else { ?>
                    <div class="badge badge-danger p-1">Hors stock</div>
                    <?php } ?>
                </div>
                <div class="card-body position-relative">
                    <h4 class="mt-0">
                        <a href="#" class="text-title"><?=$generateur['nom'] ?> </a>
                    </h4>
                    <p class="mb-3">
                        <span class="pr-2 text-nowrap">
                            <i class="mdi mdi-format-list-bulleted-type"></i>
                            <b><?=$stock ?></b> Comptes restants
                        </span>
                        <span class="text-nowrap">
                            <?php if ($generateur['verouillage'] == 1) { ?>
                                <button class="btn btn-warning text-white" disabled>Verrouillé</button>
                            <?php } elseif ($stock == 0) { ?>
                                <button class="btn btn-danger text-white" disabled>Hors stock</button>
                                <?php } elseif (check_statut_gen($stock, $utilisateur['grade'], $generateur['id'])) {
                                                if($generateur['linkvertise'] !== "0"){
                                            ?>
                                                <form method="POST">
                                                    <button type="sumbit" value="<?= $generateur['id'] ?>" name="generer" class="btn btn-success text-white">Générer</button>
                                                    <input type="hidden" name="linkvert" value="<?= $generateur['linkvertise'] ?>"></input>
                                                </form>
                                            <?php
                                                }else{
                                            ?>
                                                <form method="POST"><button type="sumbit" value="<?= $generateur['id'] ?>" name="generer" class="btn btn-success text-white">Générer</button></form>
                                            <?php
                                                }
                                            ?>
                                            <?php } else { ?>
                                                <a href="/vip" class="btn btn-warning text-white">Réservé aux VIP</a>
                                            <?php } ?>
                        </span>
                    </p>
                    <p class="mb-2 font-weight"><?=coupePhrase($generateur['description'], 140) ?></p>
                    <div class="progress progress-sm">
                        <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="10000" style="width:<?=$stock ?>%"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
     </div>
<div class="row">

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/fDuHdHl.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/G1fje6A.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/wrFrFyp.gif"></a>
</div>
</div>

<div class="col-md-6 col-xl-3">
<div class="card d-block">
<img class="card-img-top" width="400" src="https://i.imgur.com/MD3Tcb4.gif"></a>
</div>
</div>
</div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mb-3">Generadores</h4>

                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-hover mb-0">
                            <tbody>
                                <?php
                                $getGen = get_generateur();
                                while ($generateur = $getGen->fetch()) {
                                    $stock = get_stock($generateur['id']);

                                    ?>
                                    <tr>
                                        <td>
                                            <div class="media">
                                                <img class="mr-2 rounded-circle" src="<?=$generateur['icon'] ?>" width="40"/>
                                                <div class="media-body">
                                                    <h5 class="mt-0 mb-1"><?=$generateur['nom'] ?><small class="font-weight-normal ml-3 swipez"></small></h5>
                                                    <span class="font-13"><?=coupePhrase($generateur['description'], 110) ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="text-muted font-13">
                                                <i class="mdi mdi-link-variant"></i> <?php if ($utilisateur['grade'] == 1) { ?>Avec publicité<?php } else { ?>Sans publicité<?php } ?>
                                            </span>
                                            <br>
                                            <p class="mb-0"><i class="mdi mdi-format-list-bulleted-type"></i> <?=$stock ?> comptes en stock</p>
                                        </td>
                                        <td class="table-action" style="width:50px">
                                            <?php if ($generateur['verouillage'] == 1) { ?>
                                                <button class="btn btn-warning text-white" disabled>Verrouillé</button>
                                            <?php } elseif ($stock == 0) { ?>
                                                <button class="btn btn-danger text-white" disabled>Hors stock</button>
                                            <?php } elseif (check_statut_gen($stock, $utilisateur['grade'], $generateur['id'])) {
                                                if($generateur['linkvertise'] !== "0"){
                                            ?>
                                                <form method="POST">
                                                    <button type="sumbit" value="<?= $generateur['id'] ?>" name="generer" class="btn btn-success text-white">Générer</button>
                                                    <input type="hidden" name="linkvert" value="<?= $generateur['linkvertise'] ?>"></input>
                                                </form>
                                            <?php
                                                }else{
                                            ?>
                                                <form method="POST"><button type="sumbit" value="<?= $generateur['id'] ?>" name="generer" class="btn btn-success text-white">Générer</button></form>
                                            <?php
                                                }
                                            ?>
                                            <?php } else { ?>
                                                <a href="/vip" class="btn btn-warning text-white">Réservé aux VIP</a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require('inc/footer_panel.php'); 